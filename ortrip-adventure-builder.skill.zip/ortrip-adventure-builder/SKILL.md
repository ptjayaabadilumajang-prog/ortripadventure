---
name: ortrip-adventure-builder
description: Build or extend a premium Indonesian open-trip and private-trip travel app using the Or.Trip Adventure workflow. Use for Expo mobile travel apps that need trip discovery, trip details, booking, legal consent, WhatsApp conversion, gallery/journal content, official contact surfaces, and branded green adventure-travel design.
---

# Or.Trip Adventure Builder

Use this skill to create or extend an Indonesian adventure-travel booking experience with a discovery-first mobile UI, transparent trip information, safety guidance, and WhatsApp-assisted conversion.

## Core workflow

1. Inspect the current Expo project, shared theme tokens, navigation, demo-data layer, and existing booking flow before editing.
2. Capture requirements in `design.md` and `todo.md`. Add every requested feature as an unchecked item before implementation and mark it complete immediately after validation.
3. Establish the brand system: semantic color tokens, Lora headings, Mulish body copy, rounded editorial cards, accessible contrast, and portrait one-handed layouts.
4. Create typed local data models for trips, itinerary items, guides, gallery entries, journal posts, legal sections, FAQs, contacts, and bookings. Keep content in one shared data layer so a backend can replace it later.
5. Implement bottom-tab discovery screens: Home, Explore, Gallery, Journal, and Profile. Use `ScreenContainer` for every screen and semantic NativeWind classes such as `bg-background`, `bg-primary`, `bg-surface`, `text-foreground`, `text-muted`, and `border-border`.
6. Implement a dynamic trip detail route. Render the selected trip’s hero, rating, date, capacity, duration, price, inclusions, itinerary, guide, safety note, and FAQ accordion from typed data. FAQ rows must be keyboard/touch accessible and support one or multiple expanded answers.
7. Implement booking as a guarded flow. Collect participant count, contact details, travel date, and citizenship/currency state. Require explicit consent for both Privacy Policy and Booking Terms before enabling the next booking action. Link each consent label to the corresponding legal screen.
8. Build WhatsApp conversion with one shared formatter. The message must include trip name, selected date, participant count, and a short booking intent. URL-encode the message and open the official contact number. Reuse the formatter in the Home hero, trip detail CTA, booking confirmation, and global floating action where appropriate.
9. Add legal content as a dedicated screen with separate Privacy Policy and Booking Terms sections. Keep the copy specific to the product, avoid unsupported legal promises, display an update date, and make the booking consent links easy to revisit.
10. Add official business contact surfaces for admin WhatsApp numbers, email, Instagram, TikTok, website, and support. Keep these in typed configuration rather than scattering literals through components.
11. Validate with TypeScript, focused Vitest tests for pricing/consent/message formatting, and mobile-portrait screenshots for Home, Explore, Trip Detail, Booking, Legal, and Profile. Fix layout issues before checkpointing.
12. Read `todo.md`, save one recoverable checkpoint, and deliver the checkpoint plus the skill file. Never publish automatically.

## Recommended data shapes

```ts
type TripFaq = { id: string; question: string; answer: string };
type Trip = {
  id: string; title: string; type: "Open Trip" | "Private Trip";
  location: string; date: string; price: number; faqs: TripFaq[];
};
type BookingDraft = {
  tripId: string; tripName: string; date: string; participants: number;
  privacyAccepted: boolean; termsAccepted: boolean;
};
```

## WhatsApp message contract

Use one formatter and test it independently:

```ts
export function buildBookingWhatsAppMessage(input: {
  tripName: string; date: string; participants: number;
}) {
  return `Halo Or.Trip Adventure, saya ingin booking ${input.tripName}.\nTanggal: ${input.date}\nJumlah peserta: ${input.participants}`;
}
```

The booking action must refuse to proceed when either legal consent is false. The WhatsApp URL should use `https://wa.me/<digits>?text=<encoded-message>` and must never expose formatting bugs caused by spaces, punctuation, or line breaks.

## UX and accessibility rules

Prefer concise Indonesian copy, visible prices, and clear next actions. Use large touch targets, readable line heights, meaningful accessibility labels, pressed feedback, and no dead-end buttons. Show FAQ answers inline rather than forcing users to leave the trip page. Keep the floating WhatsApp button above the tab bar and safe-area region.

## Validation checklist

- Run `pnpm check`.
- Run focused tests for trip lookup, totals, legal consent gating, and WhatsApp message formatting.
- Capture mobile-portrait screenshots for the main conversion screens.
- Confirm official contact values are centralized and every WhatsApp CTA reaches the correct number.
- Read the entire project `todo.md` and ensure completed items are marked `[x]` before checkpointing.
- Run `/home/ubuntu/skills/skill-creator/scripts/quick_validate.py ortrip-adventure-builder` before delivery.
