import { useState } from 'react';
import { Linking, Modal, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { PrimaryButton } from '@/components/trip-ui';
import { trpc } from '@/lib/trpc';
import { useAuth } from '@/hooks/use-auth';
import { formatIDR } from '@/lib/demo-data';
import { IconSymbol } from '@/components/ui/icon-symbol';
import type { BookingValidationStatus } from '@/lib/booking-status';

const statuses: BookingValidationStatus[] = ['under_review', 'approved', 'rejected'];

export default function AdminDashboardScreen() {
  const { user, loading: authLoading } = useAuth();
  const [bookingCode, setBookingCode] = useState('');
  const [status, setStatus] = useState<BookingValidationStatus>('approved');
  const [message, setMessage] = useState('');
  const [activeTab, setActiveTab] = useState<'finance' | 'leads' | 'trips' | 'schedules' | 'settings'>('finance');
  const [selectedLeadId, setSelectedLeadId] = useState<number | null>(null);
  const [showNotificationTest, setShowNotificationTest] = useState(false);
  const [showLegalDocs, setShowLegalDocs] = useState(false);
  const [testTitle, setTestTitle] = useState('Tes Notifikasi');
  const [testBody, setTestBody] = useState('Halo admin, ini adalah notifikasi percobaan.');
  
  const statsQuery = trpc.booking.getStats.useQuery(undefined, { enabled: !!user });
  const listQuery = trpc.booking.list.useQuery(undefined, { enabled: !!user });
  const leadsQuery = trpc.crm.listLeads.useQuery(undefined, { enabled: !!user && activeTab === 'leads' });
  const tripsQuery = trpc.trips.list.useQuery(undefined, { enabled: !!user && activeTab === 'trips' });
  const leadDetailsQuery = trpc.crm.getLeadDetails.useQuery({ id: selectedLeadId! }, { enabled: !!user && !!selectedLeadId });
  const legalDocsQuery = trpc.legal.list.useQuery(undefined, { enabled: !!user && (activeTab === 'settings' || showLegalDocs) });

  const updateStatus = trpc.booking.updateStatus.useMutation({
    onSuccess: () => {
      statsQuery.refetch();
      listQuery.refetch();
    }
  });

  const sendTestMutation = trpc.notifications.test.useMutation();

  async function update() {
    if (!bookingCode.trim()) { setMessage('Masukkan kode booking.'); return; }
    setMessage('');
    try {
      const result = await updateStatus.mutateAsync({ bookingCode: bookingCode.trim(), status });
      setMessage('Status booking diperbarui.');
      if (result.whatsappUrl) await Linking.openURL(result.whatsappUrl);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Status belum dapat diperbarui.');
    }
  }

  if (authLoading) return <ScreenContainer className="items-center justify-center"><Text className="font-body text-muted">Memuat akses admin...</Text></ScreenContainer>;
  if (!user) return <ScreenContainer className="p-5"><Text className="font-heading text-3xl font-bold text-foreground">Akses admin</Text><Text className="mt-3 font-body leading-6 text-muted">Masuk sebagai admin Or.Trip untuk mengakses dashboard keuangan dan memvalidasi booking.</Text></ScreenContainer>;

  const stats = statsQuery.data;
  const bookings = listQuery.data ?? [];

  return (
    <ScreenContainer edges={['top', 'left', 'right', 'bottom']} className="bg-background">
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        <Text className="font-heading text-3xl font-bold text-foreground">Admin Command Center</Text>
        <Text className="mt-1 font-body text-sm text-muted">Manajemen operasional Or.Trip Adventure.</Text>

        <View className="mt-6 flex-row flex-wrap gap-2">
          {(['finance', 'leads', 'trips', 'schedules', 'settings'] as const).map((tab) => (
            <Pressable 
              key={tab} 
              onPress={() => setActiveTab(tab)} 
              className={`rounded-full px-4 py-2 ${activeTab === tab ? 'bg-primary' : 'bg-surface border border-border'}`}
            >
              <Text className={`font-body text-[10px] font-extrabold uppercase tracking-widest ${activeTab === tab ? 'text-white' : 'text-foreground'}`}>
                {tab === 'finance' ? 'Keuangan' : tab === 'leads' ? 'Leads' : tab === 'trips' ? 'Trip' : tab === 'schedules' ? 'Jadwal' : 'Config'}
              </Text>
            </Pressable>
          ))}
        </View>

        {activeTab === 'finance' && (
          <>
            <View className="mt-6 flex-row flex-wrap justify-between gap-y-4">
              <StatCard label="Total Booking" value={stats?.totalBookings ?? 0} icon="paperplane.fill" />
              <StatCard label="Revenue (Approved)" value={formatIDR(stats?.totalRevenue ?? 0)} icon="banknote.fill" color="#2D5A27" />
              <StatCard label="Pending Revenue" value={formatIDR(stats?.pendingRevenue ?? 0)} icon="clock.fill" color="#F59E0B" />
              <StatCard label="Approved/Pending" value={`${stats?.approvedBookings ?? 0} / ${stats?.pendingBookings ?? 0}`} icon="checkmark.circle.fill" />
            </View>

            <View className="mt-8 rounded-3xl border border-border bg-surface p-5">
              <Text className="font-heading text-xl font-bold text-foreground">Validasi Cepat</Text>
              <Text className="mt-1 font-body text-xs text-muted">Update status pembayaran secara manual.</Text>
              
              <TextInput 
                value={bookingCode} 
                onChangeText={setBookingCode} 
                autoCapitalize="characters" 
                placeholder="Kode Booking (OR-XXXXXX)" 
                placeholderTextColor="#879287" 
                className="mt-4 rounded-2xl border border-border bg-background px-4 py-3.5 font-body text-sm text-foreground" 
              />
              
              <View className="mt-4 flex-row flex-wrap gap-2">
                {statuses.map((item) => (
                  <Pressable 
                    key={item} 
                    onPress={() => setStatus(item)} 
                    className={`rounded-full border px-4 py-2 ${status === item ? 'bg-primary border-primary' : 'border-border bg-background'}`}
                  >
                    <Text className={`font-body text-[10px] font-extrabold uppercase tracking-widest ${status === item ? 'text-white' : 'text-foreground'}`}>
                      {item === 'under_review' ? 'Review' : item === 'approved' ? 'Setujui' : 'Tolak'}
                    </Text>
                  </Pressable>
                ))}
              </View>

              <View className="mt-5">
                <PrimaryButton 
                  label={updateStatus.isPending ? 'Menyimpan...' : 'Simpan & Buka WhatsApp'} 
                  disabled={updateStatus.isPending} 
                  onPress={update} 
                />
              </View>
              {message ? <Text className="mt-3 font-body text-xs text-center text-muted">{message}</Text> : null}
            </View>

            <View className="mt-8">
              <Text className="font-heading text-xl font-bold text-foreground">Booking Terbaru</Text>
              <View className="mt-4 gap-y-3">
                {bookings.length === 0 ? (
                  <View className="rounded-2xl border border-dashed border-border p-8 items-center">
                    <Text className="font-body text-sm text-muted">Belum ada data booking.</Text>
                  </View>
                ) : (
                  bookings.map((b) => (
                    <View key={b.bookingCode} className="rounded-2xl border border-border bg-surface p-4">
                      <View className="flex-row justify-between items-start">
                        <View className="flex-1 pr-2">
                          <Text className="font-body text-[10px] font-extrabold text-primary uppercase tracking-widest">{b.bookingCode}</Text>
                          <Text className="mt-1 font-heading text-base font-bold text-foreground">{b.customerName}</Text>
                          <Text className="font-body text-xs text-muted">{b.tripName}</Text>
                        </View>
                        <View className={`px-2 py-1 rounded-md ${b.status === 'approved' ? 'bg-success/10' : b.status === 'rejected' ? 'bg-error/10' : 'bg-warning/10'}`}>
                          <Text className={`font-body text-[10px] font-bold ${b.status === 'approved' ? 'text-success' : b.status === 'rejected' ? 'text-error' : 'text-warning'}`}>
                            {b.status.toUpperCase()}
                          </Text>
                        </View>
                      </View>
                      <View className="mt-3 pt-3 border-t border-border flex-row justify-between items-center">
                        <Text className="font-body text-xs text-muted">{new Date(b.submittedAt).toLocaleDateString('id-ID')}</Text>
                        <Text className="font-body text-sm font-extrabold text-foreground">{formatIDR(b.total)}</Text>
                      </View>
                    </View>
                  ))
                )}
              </View>
            </View>
          </>
        )}

        {activeTab === 'leads' && (
          <View className="mt-6">
            <Text className="font-heading text-xl font-bold text-foreground">Lead CRM</Text>
            <View className="mt-4 gap-y-3">
              {(leadsQuery.data ?? []).map((lead: any) => (
                <Pressable key={lead.id} onPress={() => setSelectedLeadId(lead.id)} className="rounded-2xl border border-border bg-surface p-4 active:opacity-70">
                  <View className="flex-row justify-between items-center">
                    <View>
                      <Text className="font-heading text-base font-bold text-foreground">{lead.name || 'Anonymous'}</Text>
                      <Text className="font-body text-xs text-muted">{lead.phone || lead.email || 'No contact'}</Text>
                    </View>
                    <View className="items-end">
                      <View className="rounded-full bg-primary/10 px-2 py-1">
                        <Text className="font-body text-[10px] font-bold text-primary">Score: {lead.score}</Text>
                      </View>
                      <Text className="mt-1 font-body text-[10px] text-muted">{lead.status}</Text>
                    </View>
                  </View>
                  <Text className="mt-2 font-body text-[10px] text-muted">Interest: {lead.productInterest || 'General'}</Text>
                </Pressable>
              ))}
            </View>
          </View>
        )}

        {activeTab === 'trips' && (
          <View className="mt-6">
            <Text className="font-heading text-xl font-bold text-foreground">Manajemen Trip</Text>
            <View className="mt-4 gap-y-3">
              {(tripsQuery.data ?? []).map((item: any) => {
                const trip = item.trip;
                const dest = item.destination;
                return (
                  <View key={trip.id} className="rounded-2xl border border-border bg-surface p-4">
                    <View className="flex-row justify-between items-center">
                      <View className="flex-1">
                        <Text className="font-heading text-base font-bold text-foreground">{trip.title}</Text>
                        <Text className="font-body text-xs text-muted">{dest ? `${dest.name}, ${dest.region}` : 'No Location'} · {formatIDR(parseFloat(trip.priceBase))}</Text>
                      </View>
                      <View className={`rounded-full px-3 py-1 ${trip.isVerified ? 'bg-success/10' : 'bg-error/10'}`}>
                        <Text className={`font-body text-[10px] font-bold ${trip.isVerified ? 'text-success' : 'text-error'}`}>
                          {trip.isVerified ? 'VERIFIED' : 'UNVERIFIED'}
                        </Text>
                      </View>
                    </View>
                  </View>
                );
              })}
            </View>
          </View>
        )}

        {activeTab === 'settings' && (
          <View className="mt-6">
            <Text className="font-heading text-xl font-bold text-foreground">Business Configuration</Text>
            <Text className="mt-1 font-body text-xs text-muted">Update pengaturan operasional global.</Text>
            
            <View className="mt-6 gap-y-4">
              <ConfigItem title="Official Contacts" description="Nomor WhatsApp admin, email, dan link sosial media." />
              <ConfigItem title="Pricing & Packages" description="Kelola harga dasar dan paket meeting point." />
              <ConfigItem title="Lead Scoring Rules" description="Atur bobot poin untuk aktivitas chatbot dan form." />
              <ConfigItem title="Google Sheets Integration" description="Konfigurasi URL webhook Apps Script." />
              <ConfigItem 
                title="Push Notifications" 
                description="Kirim notifikasi tes dan kelola push tokens." 
                onPress={() => setShowNotificationTest(true)}
              />
              <ConfigItem 
                title="Legal Documents" 
                description="Arsip dokumen perusahaan (NIB, NPWP, Sertifikat)." 
                onPress={() => setShowLegalDocs(true)}
              />
            </View>
          </View>
        )}
      </ScrollView>

      <Modal visible={showLegalDocs} transparent animationType="slide">
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-background rounded-t-[32px] p-6 h-[80%]">
            <View className="flex-row justify-between items-center mb-6">
              <Text className="font-heading text-2xl font-bold text-foreground">Dokumen Legal</Text>
              <Pressable onPress={() => setShowLegalDocs(false)} className="h-10 w-10 items-center justify-center rounded-full bg-surface">
                <IconSymbol name="xmark" size={20} color="#1A251B" />
              </Pressable>
            </View>
            
            <ScrollView showsVerticalScrollIndicator={false}>
              {legalDocsQuery.isLoading ? (
                <Text className="font-body text-muted">Memuat dokumen...</Text>
              ) : (legalDocsQuery.data ?? []).map((doc: any) => (
                <View key={doc.id} className="mb-4 rounded-2xl border border-border bg-surface p-4">
                  <View className="flex-row justify-between items-start">
                    <View className="flex-1">
                      <Text className="font-heading text-base font-bold text-foreground">{doc.name}</Text>
                      <Text className="font-body text-xs text-muted">No: {doc.documentNumber || '-'}</Text>
                      <Text className="mt-1 font-body text-[10px] text-primary font-bold uppercase">{doc.type}</Text>
                    </View>
                    <View className={`rounded-full px-2 py-1 ${doc.isVerified ? 'bg-success/10' : 'bg-warning/10'}`}>
                      <Text className={`font-body text-[10px] font-bold ${doc.isVerified ? 'text-success' : 'text-warning'}`}>
                        {doc.isVerified ? 'VERIFIED' : 'PENDING'}
                      </Text>
                    </View>
                  </View>
                  
                  <View className="mt-4 flex-row gap-2">
                    <Pressable 
                      onPress={() => Linking.openURL(doc.fileUrl)}
                      className="flex-1 rounded-xl bg-primary py-2.5 items-center justify-center"
                    >
                      <Text className="font-body text-xs font-bold text-white">Lihat PDF</Text>
                    </Pressable>
                  </View>
                </View>
              ))}
              
              <View className="mt-4 rounded-2xl bg-neutral p-4 border border-border border-dashed">
                <Text className="font-body text-[10px] text-muted leading-4 text-center">
                  Dokumen ini bersifat rahasia dan hanya untuk keperluan administrasi Or.Trip Adventure. Dilarang menyebarluaskan tanpa izin superadmin.
                </Text>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      <Modal visible={showNotificationTest} transparent animationType="slide">
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-background rounded-t-[32px] p-6 h-[60%]">
            <View className="flex-row justify-between items-center mb-6">
              <Text className="font-heading text-2xl font-bold text-foreground">Test Notifikasi</Text>
              <Pressable onPress={() => setShowNotificationTest(false)} className="h-10 w-10 items-center justify-center rounded-full bg-surface">
                <IconSymbol name="xmark" size={20} color="#1A251B" />
              </Pressable>
            </View>
            
            <TextInput 
              value={testTitle} 
              onChangeText={setTestTitle} 
              placeholder="Judul Notifikasi" 
              placeholderTextColor="#879287" 
              className="rounded-2xl border border-border bg-background px-4 py-3.5 font-body text-sm text-foreground" 
            />
            
            <TextInput 
              value={testBody} 
              onChangeText={setTestBody} 
              placeholder="Isi Notifikasi" 
              placeholderTextColor="#879287" 
              multiline
              className="mt-4 h-24 rounded-2xl border border-border bg-background px-4 py-3.5 font-body text-sm text-foreground" 
            />

            <View className="mt-6">
              <PrimaryButton 
                label={sendTestMutation.isPending ? 'Mengirim...' : 'Kirim ke Saya'} 
                disabled={sendTestMutation.isPending} 
                onPress={async () => {
                  try {
                    await sendTestMutation.mutateAsync({ title: testTitle, body: testBody });
                    alert('Notifikasi terkirim!');
                  } catch (e) {
                    alert('Gagal mengirim: ' + (e instanceof Error ? e.message : String(e)));
                  }
                }} 
              />
            </View>
            
            <Text className="mt-4 font-body text-[10px] text-muted text-center">
              Catatan: Pastikan Anda memberikan izin notifikasi pada perangkat fisik untuk menerima pesan ini.
            </Text>
          </View>
        </View>
      </Modal>

      <Modal visible={Boolean(selectedLeadId)} transparent animationType="slide">
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-background rounded-t-[32px] p-6 h-[80%]">
            <View className="flex-row justify-between items-center mb-6">
              <Text className="font-heading text-2xl font-bold text-foreground">Lead Details</Text>
              <Pressable onPress={() => setSelectedLeadId(null)} className="h-10 w-10 items-center justify-center rounded-full bg-surface">
                <IconSymbol name="xmark" size={20} color="#1A251B" />
              </Pressable>
            </View>
            
            {leadDetailsQuery.isLoading ? (
              <Text className="font-body text-muted">Loading details...</Text>
            ) : leadDetailsQuery.data ? (
              <ScrollView showsVerticalScrollIndicator={false}>
                <View className="rounded-3xl bg-neutral p-5">
                  <Text className="font-body text-xs font-extrabold text-primary uppercase tracking-widest">Customer Info</Text>
                  <Text className="mt-2 font-heading text-xl font-bold text-foreground">{(leadDetailsQuery.data as any).name}</Text>
                  <Text className="mt-1 font-body text-sm text-muted">{(leadDetailsQuery.data as any).phone}</Text>
                  <Text className="font-body text-sm text-muted">{(leadDetailsQuery.data as any).email}</Text>
                  
                  <View className="mt-4 flex-row gap-4">
                    <View>
                      <Text className="font-body text-[10px] text-muted uppercase">Score</Text>
                      <Text className="font-body text-lg font-extrabold text-primary">{(leadDetailsQuery.data as any).score}</Text>
                    </View>
                    <View>
                      <Text className="font-body text-[10px] text-muted uppercase">Status</Text>
                      <Text className="font-body text-lg font-extrabold text-foreground">{(leadDetailsQuery.data as any).status}</Text>
                    </View>
                  </View>
                </View>

                <Text className="mt-8 font-heading text-lg font-bold text-foreground">Activity Timeline</Text>
                <View className="mt-4 gap-y-4">
                  {((leadDetailsQuery.data as any).activities || []).map((act: any) => (
                    <View key={act.id} className="flex-row">
                      <View className="w-10 items-center">
                        <View className="h-2 w-2 rounded-full bg-primary mt-2" />
                        <View className="flex-1 w-px bg-border" />
                      </View>
                      <View className="flex-1 pb-4">
                        <Text className="font-body text-sm font-bold text-foreground">{act.action.replace(/_/g, ' ')}</Text>
                        <Text className="font-body text-[10px] text-muted">{new Date(act.createdAt).toLocaleString()}</Text>
                        {act.scoreAdded > 0 && (
                          <Text className="mt-1 font-body text-[10px] text-primary font-bold">+{act.scoreAdded} points</Text>
                        )}
                      </View>
                    </View>
                  ))}
                </View>
              </ScrollView>
            ) : null}
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}

function StatCard({ label, value, icon, color = '#1A251B' }: { label: string; value: string | number; icon: string; color?: string }) {
  return (
    <View className="w-[48%] rounded-3xl border border-border bg-surface p-4">
      <View className="h-8 w-8 items-center justify-center rounded-xl bg-neutral mb-3">
        <IconSymbol name={icon as any} size={16} color={color} />
      </View>
      <Text className="font-body text-[10px] font-extrabold text-muted uppercase tracking-widest">{label}</Text>
      <Text className="mt-1 font-heading text-lg font-bold text-foreground" style={{ color }}>{value}</Text>
    </View>
  );
}

function TripScheduleSection({ trip }: { trip: any }) {
  const { data: departures = [] } = trpc.trips.getDepartures.useQuery({ tripId: trip.id });
  
  return (
    <View className="mb-4 rounded-3xl border border-border bg-surface p-5">
      <Text className="font-heading text-lg font-bold text-foreground">{trip.title}</Text>
      <View className="mt-3 gap-y-2">
        {departures.length === 0 ? (
          <Text className="font-body text-xs text-muted italic">Belum ada jadwal keberangkatan.</Text>
        ) : (
          departures.map((d: any) => {
            const usage = ((d.seatsTotal - d.seatsAvailable) / d.seatsTotal) * 100;
            return (
              <View key={d.id} className="rounded-xl bg-background p-3">
                <View className="flex-row justify-between items-center">
                  <Text className="font-body text-xs font-bold text-foreground">
                    {new Date(d.startDate).toLocaleDateString('id-ID')}
                  </Text>
                  <Text className="font-body text-[10px] text-muted">
                    {d.seatsAvailable} / {d.seatsTotal} Kursi
                  </Text>
                </View>
                <View className="mt-2 h-1.5 w-full rounded-full bg-neutral overflow-hidden">
                  <View 
                    className={`h-full rounded-full ${usage > 90 ? 'bg-error' : usage > 70 ? 'bg-warning' : 'bg-primary'}`} 
                    style={{ width: `${usage}%` }} 
                  />
                </View>
              </View>
            );
          })
        )}
      </View>
    </View>
  );
}

function ConfigItem({ title, description, onPress }: { title: string; description: string; onPress?: () => void }) {
  return (
    <Pressable onPress={onPress} className="rounded-2xl border border-border bg-surface p-4 flex-row items-center active:opacity-70">
      <View className="flex-1">
        <Text className="font-heading text-base font-bold text-foreground">{title}</Text>
        <Text className="mt-1 font-body text-xs text-muted">{description}</Text>
      </View>
      <IconSymbol name="chevron.right" size={18} color="#2D5A27" />
    </Pressable>
  );
}
